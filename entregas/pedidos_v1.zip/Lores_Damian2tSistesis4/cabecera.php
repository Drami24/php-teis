<header>
    Usuario: <?php echo $_SESSION['usuario']->email;?>
    <a href="categorias.php">Principal</a>
    <a href="carrito.php">Ver carrito</a>
    <a href="logout.php">Cerrar sesión</a>
</header>
<hr>