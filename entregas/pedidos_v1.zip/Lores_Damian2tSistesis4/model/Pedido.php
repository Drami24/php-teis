<?php

class Pedido
{
    private $codigo;
    private $fecha;
    private $enviado;
    private $restaurante;
    
    private $productos;
}