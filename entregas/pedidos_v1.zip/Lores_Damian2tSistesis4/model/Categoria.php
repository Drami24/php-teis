<?php

class Categoria
{
    private $codigo;
    private $nombre;
    private $descripcion;
}
