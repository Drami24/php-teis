<?php

class PedidoProducto
{
    private $codigo;
    private $pedido;
    private $producto;
    private $unidades;
}