<?php

class Restaurante
{
    private $codigo;
    private $nombre;
    private $email;
    private $password;
    private $pais;
    private $ciudad;
    private $direccion;
    private $codigoPostal;
}