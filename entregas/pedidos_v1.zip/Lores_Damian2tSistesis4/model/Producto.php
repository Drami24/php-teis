<?php

class Producto
{
    private $codigo;
    private $nombre;
    private $descripcion;
    private $peso;
    private $stock;
    private $categoria;
}